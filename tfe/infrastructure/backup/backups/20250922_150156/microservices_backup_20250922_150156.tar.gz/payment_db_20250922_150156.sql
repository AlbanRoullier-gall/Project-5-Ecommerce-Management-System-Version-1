--
-- PostgreSQL database dump
--

\restrict Cvge7kDuW7HHKHbMP8Z2pNelNF6KQole2ONJ3xja4w2EDvbqxxOXK4NhJ1TQVIR

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: payment_intents; Type: TABLE; Schema: public; Owner: payment_user
--

CREATE TABLE public.payment_intents (
    id integer NOT NULL,
    stripe_payment_intent_id character varying(255) NOT NULL,
    customer_id integer NOT NULL,
    order_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'eur'::character varying NOT NULL,
    status character varying(50) DEFAULT 'requires_payment_method'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_intents OWNER TO payment_user;

--
-- Name: payment_intents_id_seq; Type: SEQUENCE; Schema: public; Owner: payment_user
--

CREATE SEQUENCE public.payment_intents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_intents_id_seq OWNER TO payment_user;

--
-- Name: payment_intents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: payment_user
--

ALTER SEQUENCE public.payment_intents_id_seq OWNED BY public.payment_intents.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: payment_user
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    stripe_payment_method_id character varying(255) NOT NULL,
    customer_id integer NOT NULL,
    type character varying(50) NOT NULL,
    card_last4 character varying(4),
    card_brand character varying(50),
    card_exp_month integer,
    card_exp_year integer,
    is_default boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_methods OWNER TO payment_user;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: payment_user
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_methods_id_seq OWNER TO payment_user;

--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: payment_user
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: refunds; Type: TABLE; Schema: public; Owner: payment_user
--

CREATE TABLE public.refunds (
    id integer NOT NULL,
    stripe_refund_id character varying(255) NOT NULL,
    payment_intent_id integer,
    amount numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    reason character varying(50),
    status character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.refunds OWNER TO payment_user;

--
-- Name: refunds_id_seq; Type: SEQUENCE; Schema: public; Owner: payment_user
--

CREATE SEQUENCE public.refunds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.refunds_id_seq OWNER TO payment_user;

--
-- Name: refunds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: payment_user
--

ALTER SEQUENCE public.refunds_id_seq OWNED BY public.refunds.id;


--
-- Name: payment_intents id; Type: DEFAULT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_intents ALTER COLUMN id SET DEFAULT nextval('public.payment_intents_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: refunds id; Type: DEFAULT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.refunds ALTER COLUMN id SET DEFAULT nextval('public.refunds_id_seq'::regclass);


--
-- Data for Name: payment_intents; Type: TABLE DATA; Schema: public; Owner: payment_user
--

COPY public.payment_intents (id, stripe_payment_intent_id, customer_id, order_id, amount, currency, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: payment_user
--

COPY public.payment_methods (id, stripe_payment_method_id, customer_id, type, card_last4, card_brand, card_exp_month, card_exp_year, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: payment_user
--

COPY public.refunds (id, stripe_refund_id, payment_intent_id, amount, currency, reason, status, created_at, updated_at) FROM stdin;
\.


--
-- Name: payment_intents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: payment_user
--

SELECT pg_catalog.setval('public.payment_intents_id_seq', 1, false);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: payment_user
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 1, false);


--
-- Name: refunds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: payment_user
--

SELECT pg_catalog.setval('public.refunds_id_seq', 1, false);


--
-- Name: payment_intents payment_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_pkey PRIMARY KEY (id);


--
-- Name: payment_intents payment_intents_stripe_payment_intent_id_key; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_stripe_payment_intent_id_key UNIQUE (stripe_payment_intent_id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_stripe_payment_method_id_key; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_stripe_payment_method_id_key UNIQUE (stripe_payment_method_id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_stripe_refund_id_key; Type: CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_stripe_refund_id_key UNIQUE (stripe_refund_id);


--
-- Name: idx_payment_intents_customer_id; Type: INDEX; Schema: public; Owner: payment_user
--

CREATE INDEX idx_payment_intents_customer_id ON public.payment_intents USING btree (customer_id);


--
-- Name: idx_payment_intents_order_id; Type: INDEX; Schema: public; Owner: payment_user
--

CREATE INDEX idx_payment_intents_order_id ON public.payment_intents USING btree (order_id);


--
-- Name: idx_payment_intents_status; Type: INDEX; Schema: public; Owner: payment_user
--

CREATE INDEX idx_payment_intents_status ON public.payment_intents USING btree (status);


--
-- Name: idx_payment_methods_customer_id; Type: INDEX; Schema: public; Owner: payment_user
--

CREATE INDEX idx_payment_methods_customer_id ON public.payment_methods USING btree (customer_id);


--
-- Name: idx_refunds_payment_intent_id; Type: INDEX; Schema: public; Owner: payment_user
--

CREATE INDEX idx_refunds_payment_intent_id ON public.refunds USING btree (payment_intent_id);


--
-- Name: refunds refunds_payment_intent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: payment_user
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_payment_intent_id_fkey FOREIGN KEY (payment_intent_id) REFERENCES public.payment_intents(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Cvge7kDuW7HHKHbMP8Z2pNelNF6KQole2ONJ3xja4w2EDvbqxxOXK4NhJ1TQVIR

